#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef double(*function)(double x);
extern double f1(double x);
extern double f2(double x);
extern double f3(double x);
extern double df1(double x);
extern double df2(double x);
extern double df3(double x);

int iteration;

int main (int argc, char *argv[]){
	double fst13 = -5, lst13 = -0,005;
	double fst23 = -5, lst23 = -0,005;
	double fst12 = -5, lst12 = 5;

	double eps1 = 0.00001;
	double eps2 = 0.00001;

	for (int i = 1; i < argc; i++){
		if (!strcmp(argv[i], "--test-integral")){

		}

		if (!strcmp(argv[i], "--test-root")){

		}

		if (!strcmp(argv[i], "--help")){
			printf(
				"Guten Tag!\nHelp:\nCommands available:\n\n--points : Prints intersection points\n--iterations : Prints number of iterations, used in counting approximate intersection points\n--area : Prints area of figure\n--test-integral : Test integral function\n--test-root : Test root function\n"
			);
		}

		if (!strcmp(argv[i], "--points")){

		}

		if (!strcmp(argv[i], "--iterations")){

		}

		if (!strcmp(argv[i], "--area")){

		}
	}

    return 0;
}
