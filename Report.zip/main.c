#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>
#include "addon.h"


// if true - case 1 (tangent method - take right point, chord method - right segment)
int method_case (double (*f)(double), double (*g)(double), double a, double b) {
	double F1 = f(a/2 + b/2) - g(a/2 + b/2);
	double F2 = (f(a) - g(a) + f(b) - g(b))/2;
	double Fa = f(a) - g(a);

	// Fa > 0 => decreases, else => increases
	// F1 - F2 > 0 => above chord, else - below
	return (Fa * (F1 - F2)) > 0;
}

// [*A, *B] - segment after 1 iteration of chord method
double chord_method_seg (double (*f)(double), double (*g)(double), double a, double b, double *A, double *B) {
	int mcase = method_case(f, g, a, b);

	double Fa = f(a) - g(a);
	double Fb = f(b) - g(b);

	double chord = (a * Fb - b * Fa) / (Fb - Fa);

	if (mcase) {
		*A = chord;
	} else {
		*B = chord;
	}
}


// [*A, *B] - segment after 1 iteration of tangent method
double tangent_method_seg ( double (*f)(double), double (*g)(double), 
							double (*df)(double), double (*dg)(double), 
							double a, double b, double *A, double *B)
{
	double d = a;
	int mcase = method_case(f, g, a, b);

	if (mcase) {
		d = b;
	}

	double Fd = f(d) - g(d);
	double dFd = df(d) - dg(d);
	double tangent = d - Fd/ dFd;

	if (mcase) {
		*B = tangent;
	} else {
		*A = tangent;
	}
}


// use combined method (both chord and tangent) to find root  of f(x) - g(x) = 0, фдыщ count iterations
double combined_method (double (*f)(double), double (*g)(double),
						double (*df)(double), double (*dg)(double),
						double a, double b, double eps1, int *iter)
{

	if ((f(a) - g(a)) * (f(b) - g(b)) > 0.0) {
		printf("Segment selected unsuccessfully. Try other boundaries.\n");
		return NAN;
	}

	if (b - a < eps1)
	{
		return a/2 + b/2;
	}

	double A = a, B = b;
	
	tangent_method_seg(f, g, df, dg, a, b, &A, &B);
	chord_method_seg(f, g, a, b, &A, &B);

	if (iter != NULL) {
		(*iter)++;	
	}
	return combined_method(f, g, df, dg, A, B, eps1, iter);
}


// use combined method to find root  of f(x) - g(x) = 0 with an accuracy of eps1
double root(double (*f)(double), double (*g)(double),
			double (*df)(double), double (*dg)(double),
			double a, double b, double eps1) {

	return combined_method(f, g, df, dg, a, b, eps1, NULL);
}


// Integrate f(x) spliting segment [a, b] into n parts
double integral_n(double (*f)(double), double a, double b, double eps2, double Iprev, int n){
	double h = (b - a)/n;
	double In = f(a)/2 + f(b)/2;

	for (int i = 1; i < n; ++i) {
		In += f(a + h * i);
	}

	In *= h;

	if (n > 1000000) {
		printf ("Integration takes too many (> 1 000 000) iterations.\n");
		return In;
	}

	if (fabs(Iprev - In)/3 < eps2) {
		return In;
	} else {
		return integral_n(f, a, b, eps2, In, 2 * n);
	}
}


// Integrate f(x) with an accuracy of eps2
double integral(double (*f)(double), double a, double b, double eps2) {
	return integral_n(f, a, b, eps2, 0.0, 10);
}

// Area between curves calculate integrals
double area_I(double x1, double x2, double x3, double eps2) {

	double I1 = integral(f1, x1, x3, eps2);
	double I2 = integral(f2, x1, x2, eps2);
	double I3 = integral(f3, x2, x3, eps2);

	return I1 - I2 - I3;
}

// Area between curves with an accuracy of eps
double curves_area (double a13, double b13, double a23, double b23, double a12, double b12, double eps1, double eps2) {
	double x1 = root(f1, f3, df1, df3, a13, b13, eps1);
	double x2 = root(f2, f3, df2, df3, a23, b23, eps1);
	double x3 = root(f1, f2, df1, df2, a12, b12, eps1);

	double I = area_I(x1, x2, x3, eps2);

	return I;
}


// -help
void help(double eps1, double eps2) {
	printf("Available keys:\n");
	printf("\t-help - for more information\n");
	printf("\t-root - print f1, f2, f2 intersections\n");
	printf("\t-iter - iterations count of root calculation\n");
	printf("\t-info - current eps1, eps2, f1, f2, f3\n");

	printf("\t-test <a> <b> <test mode> <functions> - test program\n");
	printf("\t\t<a> <b> - segment [a, b] boundaries, double\n");
	printf("\t\t<test mode> - 'r' or 'i' for testing root or integral calculation\n");
	printf("\t\t<functions> - numbers of functions, 1 <= int <= 3\n");
	printf("\t\t Examples:\n");
	printf("\t\t   -test 0.0 5.0 i 1 - integrate f1(x) from 0.0 to 5.0\n");
	printf("\t\t   -test 0.0 3.0 r 1 2 - find root of f1(x)-f2(x) = 0 on [0, 3]\n");
}

// -root
void intersection(double eps1, double eps2) {
	printf("Intersection:\n");

	double x1 = root(f1, f3, df1, df3, -2, 0, eps1);
	double x2 = root(f2, f3, df2, df3, 0, 2, eps1);
	double x3 = root(f1, f2, df1, df2, 0, 2, eps1);

	printf("\tf1, f3: x = %lf y = %lf\n", x1, f1(x1));
	printf("\tf2, f3: x = %lf y = %lf\n", x2, f2(x2));
	printf("\tf1, f2: x = %lf y = %lf\n", x3, f1(x3));\
}

// -iter
void iterations(double eps1, double eps2) {
	printf("Iterations:\n");

	int iter = 0;

	double x1 = combined_method(f1, f3, df1, df3, -2, 0, eps1, &iter);
	printf("  f1, f3: \t x = %lf \t\t iterations:  \t%d\n", x1, iter);
	iter = 0;
	double x2 = combined_method(f2, f3, df2, df3, 0, 2, eps1, &iter);
	printf("  f2, f3: \t x = %lf \t\t iterations:  \t%d\n", x2, iter);
	iter = 0;
	double x3 = combined_method(f1, f2, df1, df2, 0, 2, eps1, &iter);
	printf("  f1, f2: \t x = %lf \t\t iterations:  \t%d\n", x3, iter);
	iter = 0;

	printf("Area = %lf\n", area_I(x1, x2, x3, eps2));
}

// -test
void test(int argc, char *argv[], double eps1, double eps2) {
	double a, b;

	double (*f[])(double) = {f1, f2, f3};
	double (*df[])(double) = {df1, df2, df3};
	int i1 = 1, i2 = 2;

	if (argc < 6)
	{
		printf("Not enough arguments. -help for more information.\n");
	} else {
		sscanf(argv[2], "%lf", &a);
		sscanf(argv[3], "%lf", &b);
		sscanf(argv[5], "%d", &i1);

		if (argc == 7) {
			sscanf(argv[6], "%d", &i2);
		}

		if (strcmp(argv[4], "r") == 0) {
			if (argc < 7) {
				printf("Not enough arguments. -help for more information.\n");
			} else {
				printf("Root f%d - f%d on [%lf, %lf]:     x = %lf\n", i1, i2, a, b, root(f[i1-1], f[i2-1], df[i1-1], df[i2-1], a, b, eps1));
			}
		} else {
			printf("Integrate f%d on [%lf, %lf]:      I = %lf\n", i1, a, b, integral(f[i1-1], a, b, eps2));
		}
	}
}


// -info
void info (double eps1, double eps2) {
	printf("eps1 = %lf\n", eps1);
	printf("eps2 = %lf\n", eps2);


	printf("f1 = 1 + 4/(x^2 + 1)\n");
	printf("f2 = x^3\n");
	printf("f3 = 2^(-x)\n");
}

int main (int argc, char *argv[])
{
	double a13 = -4, b13 = 0;
	double a23 = 0, b23 = 2;
	double a12 = 0, b12 = 2;

	double eps1 = 0.00001;
	double eps2 = 0.00001;

	// key processing
	if (argc > 1) {
		char *keys[5] = {"-help", "-root", "-iter", "-info", "-test"};
		void (*op[])(double, double) = {help, intersection, iterations, info};

		for (int i = 0; i < 4; ++i) {
			if (strcmp(argv[1], keys[i]) == 0) {
				op[i](eps1, eps2);
				return 0;
			}
		}

		// -test
		if (strcmp(argv[1], keys[4]) == 0) {
			test(argc, argv, eps1, eps2);
			return 0;
		}
	}

	printf("Area = %lf\n", curves_area(a13, b13, a23, b23, a12, b12, 0.00001, 0.00001));

    return 0;
}